#!/bin/sh

PRG="$0"
ThisDir=`dirname $PRG`


${JAVA_HOME}/bin/java -jar AddressToolApp.jar 

