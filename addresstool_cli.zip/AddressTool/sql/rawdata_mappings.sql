-- rawdata_mappings.sql 
-- apply initial field mappings to a raw address data table


